# Ninja

一次对于 fastify vue3 vite 的简单尝试

**重构中，在推送到主分支以前请勿使用**
