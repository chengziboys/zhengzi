<template>
  <div class="pt-6 pb-4 text-center text-gray-600">
    <p></p>
  </div>
</template>

<script setup>
</script>